// SupportBot | Emerald Services
// Event Structure
class Event {
  constructor(event, run) {
    this.event = event;
    this.run = run;
  }
}

module.exports = Event;
